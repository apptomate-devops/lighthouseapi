<?php

namespace App\Console\Commands;

use Illuminate\Console\Command;
use Excel;
use App\Imports\ReadExcel;
use App\Imports\ReadStatistics;
use App\Imports\ReadCumulative_pb;
use App\Imports\ReadReturnsPB;
use App\Imports\ReadDrawdown;
use App\Imports\ReadMonthlyReturns;
use App\Imports\ReadReturnsA;
use App\Imports\ReadStatisticsA;
use App\Imports\Readcrisis;
use App\Imports\ReadCumulative_a;
use App\Imports\ReadStressTestNegative;
use App\Imports\ReadStressTestPositive;
use Illuminate\Support\Facades\Session;
use Illuminate\Support\Str;
use DB;
use File;

class ExcelRead extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'minute:read';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Read excel sheet in every minute';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     * @return mixed
     */
    public function handle()
    {
        
     $filename='';
     $filepath = public_path().'/output';
     $files = File::files($filepath);
     foreach($files as $data)
     {
      $filename=$data->getFilename();
      $string = Str::of($filename)->basename('.xlsx');
      $portfolio_record = DB::table('lc_portfolio')->where('portfolio_eventid','=',$string)->first();
      session()->put('curr_portfolio_id', $portfolio_record->portfolio_id);
      session()->put('curr_portfolio_user', $portfolio_record->portfolio_user);
     }
      if($filename != '')
       {
      $path =public_path().'/output/'.$filename;
      DB::beginTransaction();
      $data=Excel::import(new ReadExcel, $path);
      $data=Excel::import(new ReadStatistics, $path);
      $data=Excel::import(new ReadCumulative_pb, $path);
      $data=Excel::import(new ReadReturnsPB, $path);
      $data=Excel::import(new ReadMonthlyReturns, $path);
      $data=Excel::import(new ReadReturnsA, $path);
      $data=Excel::import(new ReadStatisticsA, $path);
      $data=Excel::import(new ReadDrawdown, $path);
      $data=Excel::import(new Readcrisis, $path);
      $data=Excel::import(new ReadCumulative_a, $path);
      $data=Excel::import(new ReadStressTestNegative, $path);
      $data=Excel::import(new ReadStressTestPositive, $path);

   
      $destinationPath = public_path('output/archive/'.$filename);
      $move = File::move($path, $destinationPath);

      DB::commit();
        echo "Data added successfully";
     }
     else
     {
      echo "No files found";
     }
  
    }
}
