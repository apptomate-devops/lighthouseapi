<?php
namespace App\Imports;

use App\User;
use Illuminate\Support\Collection;
use Illuminate\Support\Facades\DB;
use Maatwebsite\Excel\Concerns\ToCollection;
use Maatwebsite\Excel\Concerns\WithCalculatedFormulas;
use Carbon\Carbon;
use Illuminate\Support\Facades\Session;

class Drawdown implements ToCollection , WithCalculatedFormulas
{
    public function collection(Collection $rows)
    {	

     $portfolio_id = session()->get('curr_portfolio_id');
     $portfolio_user = session()->get('curr_portfolio_user');
    		$i=2;
       foreach ($rows as $row) 
        {
        	if ($i==1) {
           $data=DB::table('lc_drawdown')->insert([
    ['drawdown_client_id' => $portfolio_user,'drawdown_portfolio_id' => $portfolio_id,'drawdown_date'=>$row[0],'drawdown_cumulative'=>$row[1],'drawdown_drawdown'=>$row[2],'drawdown_msciindex'=>$row[3],'drawdown_globalequities'=>$row[4],'drawdown_addedon'=>Carbon::now(),'drawdown_addedby'=>1,'drawdown_updatedon'=>Carbon::now(),'drawdown_updatedby'=>1]
   ]);
    }
	 $i=1;        
        } 
    }
}